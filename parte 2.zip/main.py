from typing import Optional
from fastapi import FastAPI
from fastapi import Query
from DataModelX import DataModelX
import pandas as pd
from joblib import load
import numpy as np
from PredictionModel import Model
from starlette.responses import FileResponse 
from TextPreprocessing import  TextPreprocessing

app = FastAPI()


@app.post("/endpoint1")
def make_predictions(dataModel: list[DataModelX]):
    
    rows=[]
    for m in dataModel:
        dfa = pd.DataFrame(m.dict(), columns=m.dict().keys(), index=[0])
        dfa.columns = m.columns()
        rows.append(dfa)

    df=pd.concat(rows, ignore_index=True)
    model= Model()

    data_transformed=model.transform(df['Content'])

    result= model.make_predictions(data_transformed)
    lista=result.tolist()
    for i in range(len(lista)):
        if(lista[i]==1):
            lista[i]="positive"
        elif(lista[i]==0):
            lista[i]="negative"
    return str(lista)
 

@app.get("/endpoint2")
def evaluate():
    model= Model()
    result=model.metrics()
    return result 

@app.get("/")
def read_root():
   return  FileResponse('index.html')


@app.get("/items/{item_id}")
def read_item(item_id: int, q: Optional[str] = None):
   return {"item_id": item_id, "q": q}
