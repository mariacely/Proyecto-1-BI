import pandas as pd
import numpy as np
from joblib import load,dump
from sklearn.metrics import mean_squared_error, mean_absolute_error
from nltk import word_tokenize, sent_tokenize
import re, string, unicodedata
import inflect
from nltk.corpus import stopwords
from nltk.stem import LancasterStemmer, WordNetLemmatizer
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer, HashingVectorizer
from TextPreprocessing import  TextPreprocessing

class Model:
    
    def __init__(self):
        self.model = load("assets/modelo.joblib")
        self.ps=LancasterStemmer()
        self.lemmatizer=WordNetLemmatizer()
        self.data=pd.read_csv('assets/MovieReviews.csv', sep=',', encoding = 'utf-8', index_col=0)
        self.vectorizer=self.initVectorizer()

    def remove_non_ascii(words):
        new_words = []
        for word in words:
            new_word = unicodedata.normalize('NFKD', word).encode('ascii', 'ignore').decode('utf-8', 'ignore')
            new_words.append(new_word)
        return new_words

    def to_lowercase(words):
        new_words = []
        for word in words:
            new_word = word.lower()
            new_words.append(new_word)
        return new_words

    def remove_punctuation(words):
        new_words = []
        for word in words:
            new_word = re.sub(r'[^\w\s]', '', word)
            if new_word != '':
                new_words.append(new_word)
        return new_words

    def replace_numbers(words):
        p = inflect.engine()
        new_words = []
        for word in words:
            if word.isdigit():
                new_word = p.number_to_words(word)
                new_words.append(new_word)
            else:
                new_words.append(word)
        return new_words

    def remove_stopwords(words):
        new_words = []
        for word in words:
            if not word in stopwords.words():
                new_words.append(word)
        return new_words

    def preprocessing(words):
        words = Model.to_lowercase(words)
        words = Model.replace_numbers(words)
        words = Model.remove_punctuation(words)
        words = Model.remove_non_ascii(words)
        words = Model.remove_stopwords(words)
        return words

    def stem_words(self,words):
        new_words = []
        for word in words:
            new_words.append(self.ps.stem(word))
        return new_words

    def lemmatize_verbs(self,words):
        new_words = []
        for word in words:
            new_words.append(self.lemmatizer.lemmatize(word))
        return new_words

    def stem_and_lemmatize(self,words):
        words = self.stem_words(words)
        words = self.lemmatize_verbs(words)
        return words
    
    def initVectorizer(self):
        data_t=self.data
        X_data= data_t['review_es']
        vectorizer = CountVectorizer(lowercase=False)
        self.x_data=vectorizer.fit_transform(X_data)
        return vectorizer


    def transform(self,data):
        words=data.apply(word_tokenize).apply(Model.preprocessing)
        words=words.apply(self.stem_and_lemmatize)
        words= words.apply(lambda x: ' '.join(map(str, x)))
        vec = self.vectorizer.transform(words)
        return vec


    def make_predictions(self,data):
        result = self.model.predict(data)
        return result
    
    
    def metrics(self):
        
        x = self.x_data
        y = self.data['sentimiento']
        y = (y == 'positivo').astype(int)

        y_pred=self.model.predict(x)
        rmse=mean_squared_error(y,y_pred,squared=False)
        r2= self.model.score(x,y)
        mae=mean_absolute_error(y,y_pred)

        return "R2: "+str(r2)+", RMSE: "+str(rmse)+", MAE: "+str(mae)

        
    
