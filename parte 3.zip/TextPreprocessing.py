#Manejo de datos
import pandas as pd
import numpy as np

import re, string, unicodedata
import contractions
import inflect # Correctly generate plurals, singular nouns, ordinals, indefinite articles; convert numbers to words.
from nltk import word_tokenize, sent_tokenize
from nltk.corpus import stopwords
from nltk.stem import SnowballStemmer, WordNetLemmatizer
from wordcloud import WordCloud, STOPWORDS

#Entrenamiento del modelo
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.pipeline import Pipeline
from sklearn.base import BaseEstimator,TransformerMixin
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.ensemble import AdaBoostClassifier

class TextPreprocessing(BaseEstimator,TransformerMixin):
    
    def __init__(self,stopwords=stopwords.words('spanish')):
        self.stopwords = stopwords

    # Paso 1: Convertir todos los caracteres a minúsculas
    def to_lowercase(self,words):
        """Convierte todos los caracteres de una lista de palabras tokenizadas a minúsculas"""
        new_words = []
        for word in words:
            new_word = word.lower()
            new_words.append(new_word)
        return new_words

    # Paso 2: Reemplazar los números
    def replace_numbers(self,words):
        """Reemplaza todas las ocurrencias de números enteros en una lista de palabras tokenizadas con su representación textual"""
        p = inflect.engine()
        new_words = []
        for word in words:
            if word.isdigit():
                new_word = p.number_to_words(word)
                new_words.append(new_word)
            else:
                new_words.append(word)
        return new_words

    # Paso 3: Eliminar la puntuación
    def remove_punctuation(self,words):
        """Elimina la puntuación de una lista de palabras tokenizadas"""
        new_words = []
        for word in words:
            new_word = re.sub(r'[^\w\s]', '', word)
            if new_word != '':
                new_words.append(new_word)
        return new_words

    # Paso 4: Eliminar caracteres no ASCII
    def remove_non_ascii(self,words):
        """Elimina los caracteres no ASCII de una lista de palabras tokenizadas"""
        new_words = []
        for word in words:
            new_word = unicodedata.normalize('NFKD', word).encode('ascii', 'ignore').decode('utf-8', 'ignore')
            new_words.append(new_word)
        return new_words

    # Paso 5: Remover stopwords
    def remove_stopwords(self,words, stopwords=stopwords.words('spanish')):
        """Elimina las palabras vacías de una lista de palabras tokenizadas"""
        new_words = []
        for word in words:
            if word not in stopwords:
                new_words.append(word)
        return new_words

    # Paso 6: Aplicar la raíz
    def stem_words(self, words):
        """Palabras clave en la lista de palabras tokenizadas"""
        stemmer = SnowballStemmer('spanish')
        stems = []
        for word in words:
            stem = stemmer.stem(word)
            stems.append(stem)
        return stems

    # Paso 7: Aplicar la lematización
    def lemmatize_verbs(self, words):
        """Lematizar verbos en lista de palabras tokenizadas"""
        lemmatizer = WordNetLemmatizer()
        lemmas = []
        for word in words:
            lemma = lemmatizer.lemmatize(word, pos='v')
            lemmas.append(lemma)
        return lemmas

    # Aplicar la raíz y la lematización: Pasos 6 y 7
    def stem_and_lemmatize(self, words):
        words = self.stem_words(words)
        words = self.lemmatize_verbs(words)
        return words

    
    # Preprocesamiento: Pasos 1-5
    def preproccesing(self, words):
        words = self.to_lowercase(words) # 1
        words = self.replace_numbers(words) # 2
        words = self.remove_punctuation(words) # 3
        words = self.remove_non_ascii(words) # 4    
        words = self.remove_stopwords(words) # 5
        return words

    def fit(self,X,y=None):
        return self
    
    def transform(self,X,y=None):
        new_X_train = pd.Series(X)
        new_X_train = new_X_train.apply(contractions.fix) # Corregir las contracciones
        new_X_train = new_X_train.apply(word_tokenize) #  Tokenizar
        new_X_train = new_X_train.apply(lambda x: self.preproccesing(x)) # Preprocesamiento
        new_X_train = new_X_train.apply(lambda x: self.stem_and_lemmatize(x)) # Aplicar la raíz y la lematización
        new_X_train = new_X_train.apply(lambda x: ' '.join(map(str, x))) # Convertir la lista de palabras en una cadena de texto
        return new_X_train